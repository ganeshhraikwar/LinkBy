import React from 'react';
import { Zap, ArrowRight, Timer } from 'lucide-react';

const PromoBanner: React.FC = () => {
  return (
    <div className="relative overflow-hidden w-full bg-gradient-to-r from-[#ff0055] via-[#990033] to-black border-y border-[#ff0055]/30 group hover:border-[#ff0055]/60 transition-colors duration-500">
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
      
      {/* Animated Shine */}
      <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12 animate-[shimmer_3s_infinite]"></div>

      <div className="max-w-[1600px] mx-auto px-4 py-4 md:px-12 relative z-10 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
        
        <div className="flex items-center gap-4 animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
          <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center animate-heartbeat border border-white/20">
            <Zap className="w-6 h-6 text-yellow-300 fill-yellow-300" />
          </div>
          <div>
            <h3 className="text-white font-heading font-bold text-xl md:text-2xl uppercase italic tracking-wider group-hover:text-yellow-300 transition-colors">
              Ultimate Creator Bundle
            </h3>
            <p className="text-gray-200 text-xs md:text-sm font-mono">
              Get all 500+ Premium Assets + Lifetime Updates
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6 animate-slide-in-left" style={{ animationDelay: '0.4s' }}>
           <div className="hidden md:flex flex-col items-end">
             <span className="text-xs text-red-200 font-bold uppercase tracking-widest flex items-center gap-1 animate-pulse">
               <Timer className="w-3 h-3 animate-wiggle" /> Offer Ends Soon
             </span>
             <div className="flex items-baseline gap-2">
                <span className="text-gray-400 line-through text-sm font-bold">$199</span>
                <span className="text-white text-3xl font-black italic animate-pulse-slow">$29</span>
             </div>
           </div>

           <button className="group relative px-8 py-3 bg-white text-black font-black uppercase tracking-widest text-sm hover:bg-yellow-300 transition-colors skew-x-[-10deg] hover:scale-110 hover:rotate-2 duration-300 shadow-[0_0_20px_rgba(255,255,255,0.4)]">
             <span className="block skew-x-[10deg] flex items-center gap-2">
               Get Access <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
             </span>
           </button>
        </div>

      </div>
    </div>
  );
};

export default PromoBanner;