import React, { useState, useEffect } from 'react';
import { Menu, X, ShoppingCart, User, Zap } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 w-full z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-[#030303]/90 backdrop-blur-xl border-b border-white/5 py-3 shadow-[0_4px_30px_rgba(0,0,0,0.5)]' 
          : 'bg-transparent py-6'
      }`}
    >
      <div className="px-4 md:px-12 flex items-center justify-between max-w-[1600px] mx-auto relative">
        {/* Logo - Slides in from left */}
        <div className="flex items-center gap-3 group cursor-pointer relative z-10 animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
          <div className="w-10 h-10 rounded-lg bg-black border border-[#ff0055] flex items-center justify-center transform group-hover:rotate-[360deg] transition-transform duration-700 shadow-[0_0_20px_rgba(255,0,85,0.4)] animate-pulse-slow">
             <Zap className="text-[#ff0055] w-6 h-6 fill-current" />
          </div>
          <a href="#" className="font-heading text-2xl font-bold tracking-tight text-white group-hover:text-[#ff0055] transition-colors duration-300 glitch-text" data-text="BY EDITORS">
            BY EDITORS
          </a>
        </div>

        {/* Desktop Links - Staggered Slide Down */}
        <ul className="hidden md:flex items-center gap-10 text-sm font-bold text-gray-400 uppercase tracking-widest">
          {['Home', 'Store', 'Tutorials', 'Discord'].map((item, i) => (
            <li 
              key={item} 
              className="hover:text-white cursor-pointer transition relative group py-2 animate-slide-down"
              style={{ animationDelay: `${0.2 + (i * 0.1)}s` }}
            >
              <span className="relative z-10 group-hover:scale-110 block transition-transform duration-200">{item}</span>
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#ff0055] transition-all duration-300 group-hover:w-full shadow-[0_0_10px_#ff0055]"></span>
              <span className="absolute bottom-0 right-0 w-0 h-[2px] bg-[#00ccff] transition-all duration-300 delay-75 group-hover:w-full shadow-[0_0_10px_#00ccff]"></span>
            </li>
          ))}
        </ul>
        
        {/* Actions - Slide in from right */}
        <div className="flex items-center gap-6 z-10 animate-slide-in-left" style={{ animationDelay: '0.1s' }}>
          <div className="relative cursor-pointer hover:text-[#ff0055] transition-colors text-white group hover:scale-110 duration-300">
            <ShoppingCart className="w-5 h-5 group-hover:animate-wiggle" />
            <span className="absolute -top-2 -right-2 bg-[#ff0055] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold shadow-[0_0_10px_#ff0055] animate-pop-in" style={{ animationDelay: '0.8s' }}>2</span>
          </div>
          
          <button className="hidden sm:flex items-center gap-2 bg-transparent border border-white/20 text-white px-6 py-2 rounded font-bold uppercase text-xs tracking-widest transition-all hover:bg-white hover:text-black hover:shadow-[0_0_20px_rgba(255,255,255,0.5)] active:scale-95 animate-pop-in" style={{ animationDelay: '0.5s' }}>
             <span>Login</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;