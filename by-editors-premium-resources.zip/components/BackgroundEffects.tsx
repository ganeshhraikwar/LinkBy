import React, { useEffect, useState } from 'react';

const BackgroundEffects: React.FC = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMove);
    return () => window.removeEventListener('mousemove', handleMove);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Moving Retro Grid Floor */}
      <div className="retro-grid opacity-20"></div>

      {/* Dynamic Spotlight following mouse */}
      <div 
        className="absolute w-[800px] h-[800px] rounded-full blur-[100px] opacity-10 transition-transform duration-75 ease-out"
        style={{
          background: 'radial-gradient(circle, rgba(255,0,85,0.3) 0%, rgba(0,0,0,0) 70%)',
          left: -400,
          top: -400,
          transform: `translate(${mousePos.x}px, ${mousePos.y}px)`
        }}
      />
      
      {/* Ambient Gradient Blobs */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/10 blur-[150px] rounded-full animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-purple-600/10 blur-[150px] rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
    </div>
  );
};

export default BackgroundEffects;