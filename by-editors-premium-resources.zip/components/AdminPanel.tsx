import React, { useState } from 'react';
import { X, Copy, Check } from 'lucide-react';
import { Category } from '../types';

interface AdminPanelProps {
  onClose: () => void;
}

const categories: Category[] = [
  'Mobile Editing', 'PC Software', 'Plugins', 'GFX', 'PNGs', 'Icons', 'GIFs', 'Backgrounds', 'Overlays', 'Motion', 'Presets', 'Sound', '3D Assets'
];

const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    link: '',
    image: '',
    category: 'GFX',
    description: ''
  });
  const [generatedCode, setGeneratedCode] = useState('');
  const [copied, setCopied] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const generateCode = () => {
    const id = Math.floor(Math.random() * 10000).toString();
    const code = `{
    id: '${id}',
    name: "${formData.name}",
    size: "N/A", // Update size manually
    link: "${formData.link}",
    category: "${formData.category}",
    downloadCount: 0,
    isPremium: ${Number(formData.price) > 0},
    price: ${Number(formData.price)},
    image: "${formData.image || 'https://via.placeholder.com/800x450'}",
    rating: 5.0,
    isNew: true,
    longDescription: "${formData.description}"
  },`;
    setGeneratedCode(code);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl">
       <div className="w-full max-w-4xl bg-[#0a0a0a] border border-[#00ccff]/30 rounded-xl overflow-hidden flex flex-col max-h-[90vh]">
          {/* Header */}
          <div className="bg-[#00ccff]/10 p-4 border-b border-[#00ccff]/20 flex justify-between items-center">
             <h2 className="text-[#00ccff] font-mono font-bold text-lg flex items-center gap-2">
                <span className="w-2 h-2 bg-[#00ccff] rounded-full animate-pulse"></span>
                ADMIN CONSOLE :: RESOURCE_GENERATOR
             </h2>
             <button onClick={onClose} className="text-[#00ccff] hover:text-white"><X /></button>
          </div>

          <div className="flex flex-col lg:flex-row flex-grow overflow-hidden">
             {/* Form */}
             <div className="w-full lg:w-1/2 p-6 overflow-y-auto border-r border-white/10">
                <div className="space-y-4">
                   <div>
                      <label className="block text-xs font-mono text-gray-500 mb-1">PRODUCT NAME</label>
                      <input name="name" onChange={handleChange} className="w-full bg-[#111] border border-white/10 p-2 text-white rounded focus:border-[#00ccff] outline-none" placeholder="e.g. Mega GFX Pack" />
                   </div>
                   <div className="flex gap-4">
                      <div className="flex-1">
                        <label className="block text-xs font-mono text-gray-500 mb-1">PRICE ($)</label>
                        <input name="price" type="number" onChange={handleChange} className="w-full bg-[#111] border border-white/10 p-2 text-white rounded focus:border-[#00ccff] outline-none" placeholder="0 for Free" />
                      </div>
                      <div className="flex-1">
                        <label className="block text-xs font-mono text-gray-500 mb-1">CATEGORY</label>
                        <select name="category" onChange={handleChange} className="w-full bg-[#111] border border-white/10 p-2 text-white rounded focus:border-[#00ccff] outline-none">
                           {categories.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                   </div>
                   <div>
                      <label className="block text-xs font-mono text-gray-500 mb-1">DOWNLOAD LINK (Drive/Mediafire)</label>
                      <input name="link" onChange={handleChange} className="w-full bg-[#111] border border-white/10 p-2 text-white rounded focus:border-[#00ccff] outline-none" placeholder="https://..." />
                   </div>
                   <div>
                      <label className="block text-xs font-mono text-gray-500 mb-1">IMAGE URL</label>
                      <input name="image" onChange={handleChange} className="w-full bg-[#111] border border-white/10 p-2 text-white rounded focus:border-[#00ccff] outline-none" placeholder="https://..." />
                   </div>
                   <div>
                      <label className="block text-xs font-mono text-gray-500 mb-1">DESCRIPTION</label>
                      <textarea name="description" onChange={handleChange} className="w-full bg-[#111] border border-white/10 p-2 text-white rounded focus:border-[#00ccff] outline-none h-24" placeholder="Product details..." />
                   </div>
                   <button onClick={generateCode} className="w-full py-3 bg-[#00ccff] text-black font-bold rounded hover:bg-white transition-colors shadow-[0_0_15px_rgba(0,204,255,0.4)]">
                      GENERATE CODE
                   </button>
                </div>
             </div>

             {/* Output */}
             <div className="w-full lg:w-1/2 p-6 bg-[#050505] flex flex-col">
                <label className="block text-xs font-mono text-gray-500 mb-1">GENERATED JSON (Copy & Paste into data/resources.ts)</label>
                <div className="flex-grow bg-[#111] border border-white/10 rounded p-4 font-mono text-xs text-green-400 overflow-auto whitespace-pre relative group">
                   {generatedCode || "// Fill form to generate code..."}
                   <button onClick={copyToClipboard} className="absolute top-2 right-2 p-2 bg-white/10 rounded hover:bg-white/20 text-white">
                      {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                   </button>
                </div>
                <p className="text-[10px] text-gray-500 mt-2">
                   * Instructions: Copy this code block. Open `data/resources.ts`. Paste it inside the `resources` array.
                </p>
             </div>
          </div>
       </div>
    </div>
  );
};

export default AdminPanel;