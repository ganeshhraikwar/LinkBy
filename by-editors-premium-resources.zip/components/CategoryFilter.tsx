import React from 'react';
import { Category } from '../types';

interface CategoryFilterProps {
  selectedCategory: Category;
  onSelectCategory: (category: Category) => void;
}

const categories: Category[] = [
  'All', 
  'New Arrivals', 
  'Mobile Editing', 
  'PC Software', 
  'Plugins', 
  'GFX', 
  'PNGs',
  'Icons',
  'GIFs',
  'Backgrounds',
  'Overlays', 
  'Motion', 
  'Presets', 
  'Sound', 
  '3D Assets'
];

const CategoryFilter: React.FC<CategoryFilterProps> = ({ selectedCategory, onSelectCategory }) => {
  return (
    <div className="flex flex-wrap gap-3 mb-8 justify-center md:justify-start">
      {categories.map((cat, index) => (
        <button
          key={cat}
          onClick={() => onSelectCategory(cat)}
          style={{ animationDelay: `${0.3 + (index * 0.05)}s` }}
          className={`px-5 py-2 rounded-xl text-sm font-semibold transition-all duration-300 border relative overflow-hidden group animate-pop-in
            ${selectedCategory === cat 
              ? 'bg-[#ff0055] text-white border-[#ff0055] shadow-[0_0_20px_rgba(255,0,85,0.4)] scale-105' 
              : 'bg-[#121212] text-gray-400 border-white/10 hover:border-white/30 hover:text-white hover:scale-105'
            }`}
        >
          <span className="relative z-10 group-hover:animate-pulse">{cat}</span>
          {selectedCategory !== cat && (
             <div className="absolute inset-0 bg-white/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
          )}
        </button>
      ))}
    </div>
  );
};

export default CategoryFilter;