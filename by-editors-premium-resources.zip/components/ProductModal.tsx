import React from 'react';
import { Resource } from '../types';
import { X, Download, ShoppingBag, Shield, Check, Star, CreditCard, Smartphone, Globe, Bitcoin } from 'lucide-react';

interface ProductModalProps {
  resource: Resource;
  onClose: () => void;
  onBuy: () => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ resource, onClose, onBuy }) => {
  const isPaid = resource.price && resource.price > 0;

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in-up overflow-y-auto">
      <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl w-full max-w-5xl overflow-hidden relative shadow-2xl flex flex-col lg:flex-row mt-10 mb-10">
        <button 
            onClick={onClose} 
            className="absolute top-4 right-4 z-50 w-10 h-10 bg-black/50 backdrop-blur rounded-full flex items-center justify-center text-white hover:bg-[#ff0055] transition-colors"
        >
            <X className="w-5 h-5" />
        </button>

        {/* Media Side */}
        <div className="w-full lg:w-3/5 bg-black relative group">
           {resource.videoPreview ? (
             <video src={resource.videoPreview} autoPlay muted loop className="w-full h-full object-cover opacity-80" />
           ) : (
             <img src={resource.image} alt={resource.name} className="w-full h-full object-cover" />
           )}
           <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent"></div>
           
           <div className="absolute bottom-6 left-6 right-6">
              <div className="flex gap-2 mb-2">
                 <span className="bg-[#ff0055] text-white text-[10px] font-bold px-2 py-1 rounded">{resource.category}</span>
                 {resource.isNew && <span className="bg-[#00ccff] text-black text-[10px] font-bold px-2 py-1 rounded">NEW DROP</span>}
              </div>
              <h1 className="text-3xl md:text-5xl font-heading font-bold text-white mb-2">{resource.name}</h1>
           </div>
        </div>

        {/* Details Side */}
        <div className="w-full lg:w-2/5 p-8 flex flex-col bg-[#0a0a0a]">
           
           <div className="flex items-center gap-4 mb-6 pb-6 border-b border-white/5">
              <div className="flex-1">
                 <p className="text-gray-500 text-xs uppercase tracking-widest mb-1">Price</p>
                 <p className={`text-3xl font-bold ${isPaid ? 'text-[#ff0055]' : 'text-[#00ff9d]'}`}>
                    {isPaid ? `$${resource.price}` : 'FREE'}
                 </p>
              </div>
              <div className="flex-1 text-right">
                 <p className="text-gray-500 text-xs uppercase tracking-widest mb-1">Rating</p>
                 <div className="flex items-center justify-end gap-1 text-yellow-400">
                    <span className="font-bold text-xl">{resource.rating || 5.0}</span>
                    <Star className="w-4 h-4 fill-current" />
                 </div>
              </div>
           </div>

           <div className="prose prose-invert prose-sm mb-8 text-gray-300">
             <p>{resource.longDescription || "Includes high-quality assets ready for drag-and-drop. Compatible with Premiere Pro, After Effects, DaVinci Resolve, and CapCut."}</p>
             <ul className="list-none space-y-2 pl-0 mt-4">
               {['Instant Digital Download', 'Commercial License Included', 'High Quality 4K/HD', '24/7 Support'].map((feat, i) => (
                  <li key={i} className="flex items-center gap-2 text-xs">
                     <div className="w-4 h-4 rounded-full bg-[#00ff9d]/20 flex items-center justify-center">
                        <Check className="w-2 h-2 text-[#00ff9d]" />
                     </div>
                     {feat}
                  </li>
               ))}
             </ul>
           </div>

           <div className="mt-auto space-y-4">
              {isPaid ? (
                  <>
                    <button 
                      onClick={onBuy}
                      className="w-full py-4 bg-gradient-to-r from-[#ff0055] to-[#cc0044] text-white font-black uppercase tracking-widest text-sm rounded hover:scale-105 transition-transform shadow-[0_0_30px_rgba(255,0,85,0.3)] flex items-center justify-center gap-2"
                    >
                      <ShoppingBag className="w-5 h-5" /> Buy Now
                    </button>
                    {/* Payment Badges */}
                    <div className="flex justify-center gap-3 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
                       <CreditCard className="w-5 h-5 text-blue-400" />
                       <Smartphone className="w-5 h-5 text-green-400" />
                       <Globe className="w-5 h-5 text-blue-600" />
                       <Bitcoin className="w-5 h-5 text-orange-500" />
                    </div>
                  </>
              ) : (
                  <a href={resource.link} target="_blank" rel="noreferrer" className="block w-full">
                    <button className="w-full py-4 bg-[#1a1a1a] border border-white/10 text-white font-bold uppercase tracking-widest text-sm rounded hover:bg-white hover:text-black transition-all flex items-center justify-center gap-2">
                        <Download className="w-5 h-5" /> Download Free
                    </button>
                  </a>
              )}
              
              <p className="text-[10px] text-center text-gray-600 flex items-center justify-center gap-1">
                 <Shield className="w-3 h-3" /> Files verified by admin. Virus free.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;