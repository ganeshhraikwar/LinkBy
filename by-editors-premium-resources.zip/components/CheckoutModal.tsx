import React, { useState } from 'react';
import { Resource } from '../types';
import { X, CheckCircle, Shield, AlertTriangle, Download, Copy, CreditCard, Smartphone, Globe, Bitcoin, Wallet, Zap, Lock } from 'lucide-react';

interface CheckoutModalProps {
  resource: Resource;
  onClose: () => void;
}

type PaymentMethod = 'CARD' | 'UPI' | 'PAYPAL' | 'CRYPTO' | 'APPLE_GOOGLE';

const CheckoutModal: React.FC<CheckoutModalProps> = ({ resource, onClose }) => {
  const [method, setMethod] = useState<PaymentMethod>('UPI'); // Default to UPI for Indian context, or CARD for global
  const [txnId, setTxnId] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // --- CONFIGURATION (Replace with your actual details) ---
  const UPI_ID = "your-upi@okaxis"; 
  const PAYPAL_USER = "yourusername";
  const CRYPTO_WALLETS = {
    BTC: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
    ETH: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    USDT: "TKr99px634234234234234234234"
  };

  const QR_CODE_API = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=${UPI_ID}&pn=ByEditors&am=${resource.price}&cu=INR`;

  const handleVerify = () => {
    if ((method === 'UPI' || method === 'CRYPTO') && !txnId) {
      alert("Please enter the Transaction ID / Hash so we can verify your payment.");
      return;
    }
    
    setIsVerifying(true);
    
    // Simulate Server Verification
    setTimeout(() => {
      setIsVerifying(false);
      setIsSuccess(true);
    }, 2500);
  };

  // --- SUCCESS VIEW ---
  if (isSuccess) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fade-in-up">
        <div className="bg-[#0a0a0a] border border-[#00ff9d] rounded-2xl p-10 max-w-md w-full text-center relative overflow-hidden shadow-[0_0_50px_rgba(0,255,157,0.2)]">
           {/* Confetti / Success Animation Background */}
           <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
           
           <div className="relative z-10">
             <div className="w-24 h-24 bg-[#00ff9d]/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-[#00ff9d]/30 animate-pop-in">
                <CheckCircle className="w-12 h-12 text-[#00ff9d]" />
             </div>
             <h2 className="text-3xl font-heading font-bold text-white mb-2">Payment Confirmed</h2>
             <p className="text-gray-400 mb-8 font-mono text-sm">Transaction ID: #{Math.floor(Math.random() * 100000000)}</p>
             
             <div className="bg-[#111] p-4 rounded-xl border border-white/10 mb-8 flex items-center gap-4 text-left">
                <img src={resource.image} className="w-12 h-12 rounded bg-gray-800 object-cover" alt="" />
                <div>
                   <h4 className="font-bold text-white text-sm line-clamp-1">{resource.name}</h4>
                   <p className="text-xs text-[#00ff9d]">Ready for download</p>
                </div>
             </div>

             <a href={resource.link} target="_blank" rel="noreferrer" className="block w-full group">
               <button className="w-full py-4 bg-[#00ff9d] text-black font-black uppercase tracking-widest rounded-xl hover:scale-105 transition-transform flex items-center justify-center gap-3 shadow-[0_0_20px_#00ff9d]">
                  <Download className="w-5 h-5 group-hover:animate-bounce" /> Download Assets
               </button>
             </a>
             
             <button onClick={onClose} className="mt-6 text-xs text-gray-500 hover:text-white transition-colors">Close Window</button>
           </div>
        </div>
      </div>
    );
  }

  // --- MAIN PAYMENT VIEW ---
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in-up">
      <div className="bg-[#0f0f0f] border border-white/10 rounded-2xl w-full max-w-5xl flex flex-col md:flex-row overflow-hidden shadow-2xl relative h-[90vh] md:h-auto">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-white z-20 hover:rotate-90 transition-transform"><X className="w-6 h-6" /></button>

        {/* SIDEBAR: PAYMENT METHODS */}
        <div className="w-full md:w-1/4 bg-[#050505] border-r border-white/5 flex flex-col">
           <div className="p-6 border-b border-white/5 bg-[#0a0a0a]">
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Secure Checkout</h3>
              <div className="flex items-baseline gap-1">
                 <span className="text-xs text-[#ff0055]">$</span>
                 <span className="text-2xl font-bold text-white">{resource.price}</span>
                 <span className="text-xs text-gray-500">USD</span>
              </div>
           </div>
           
           <div className="flex-grow overflow-y-auto p-2 space-y-1">
              {[
                { id: 'UPI', label: 'UPI / QR Code', icon: Smartphone, color: 'text-[#ff0055]' },
                { id: 'CARD', label: 'Credit / Debit Card', icon: CreditCard, color: 'text-blue-400' },
                { id: 'PAYPAL', label: 'PayPal', icon: Globe, color: 'text-blue-600' },
                { id: 'CRYPTO', label: 'Crypto (BTC/ETH)', icon: Bitcoin, color: 'text-orange-500' },
                { id: 'APPLE_GOOGLE', label: 'Apple / Google Pay', icon: Wallet, color: 'text-white' },
              ].map((m) => (
                <button 
                  key={m.id}
                  onClick={() => setMethod(m.id as PaymentMethod)}
                  className={`w-full text-left p-4 rounded-lg flex items-center gap-3 transition-all duration-200 border ${method === m.id ? 'bg-[#1a1a1a] border-[#ff0055]/50 shadow-[inset_0_0_20px_rgba(0,0,0,0.5)]' : 'bg-transparent border-transparent hover:bg-white/5'}`}
                >
                   <div className={`w-8 h-8 rounded-full bg-black border border-white/10 flex items-center justify-center ${method === m.id ? 'scale-110' : ''}`}>
                      <m.icon className={`w-4 h-4 ${m.color}`} />
                   </div>
                   <span className={`text-sm font-bold ${method === m.id ? 'text-white' : 'text-gray-400'}`}>{m.label}</span>
                   {method === m.id && <div className="ml-auto w-2 h-2 rounded-full bg-[#ff0055] animate-pulse"></div>}
                </button>
              ))}
           </div>
           
           <div className="p-4 border-t border-white/5 text-[10px] text-gray-600 flex items-center justify-center gap-2">
              <Lock className="w-3 h-3" /> Encrypted & Secure
           </div>
        </div>

        {/* MAIN CONTENT AREA */}
        <div className="w-full md:w-3/4 bg-[#0a0a0a] p-8 md:p-10 overflow-y-auto relative">
           
           {/* Header for Method */}
           <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-2">
                 {method === 'UPI' && 'Pay via UPI / QR'}
                 {method === 'CARD' && 'Pay with Card'}
                 {method === 'PAYPAL' && 'Pay with PayPal'}
                 {method === 'CRYPTO' && 'Pay with Crypto'}
                 {method === 'APPLE_GOOGLE' && 'Digital Wallet'}
              </h2>
              <p className="text-gray-500 text-sm">Complete your purchase to unlock assets instantly.</p>
           </div>

           {/* --- UPI SECTION --- */}
           {method === 'UPI' && (
             <div className="animate-fade-in-up">
                <div className="flex flex-col md:flex-row gap-8 items-center mb-8">
                   <div className="bg-white p-3 rounded-xl shadow-[0_0_30px_rgba(255,255,255,0.05)] relative group">
                      <div className="absolute inset-0 bg-gradient-to-tr from-[#ff0055] to-[#00ccff] opacity-0 group-hover:opacity-20 transition-opacity rounded-xl blur-lg"></div>
                      <img src={QR_CODE_API} alt="Scan to Pay" className="w-48 h-48 relative z-10 mix-blend-multiply" />
                   </div>
                   <div className="space-y-4 w-full max-w-sm">
                      <div className="bg-[#111] border border-white/10 p-4 rounded-lg">
                         <label className="text-xs text-gray-500 block mb-1">UPI ID</label>
                         <div className="flex items-center justify-between text-[#00ff9d] font-mono">
                            <span>{UPI_ID}</span>
                            <Copy className="w-4 h-4 text-gray-400 cursor-pointer hover:text-white transition-colors" />
                         </div>
                      </div>
                      <div className="bg-[#111] border border-white/10 p-4 rounded-lg">
                         <label className="text-xs text-gray-500 block mb-1">Amount</label>
                         <div className="text-white font-bold">₹{(resource.price! * 83).toFixed(0)} <span className="text-xs font-normal text-gray-500">(approx)</span></div>
                      </div>
                      <p className="text-xs text-gray-400 flex items-center gap-2">
                         <Zap className="w-3 h-3 text-yellow-400" /> Use PhonePe, GPay, Paytm or any UPI app.
                      </p>
                   </div>
                </div>

                <div className="bg-[#111] border border-white/10 p-6 rounded-xl">
                   <label className="block text-sm font-bold text-white mb-2">Enter Transaction ID (UTR)</label>
                   <div className="flex gap-4">
                      <input 
                        type="text" 
                        value={txnId}
                        onChange={(e) => setTxnId(e.target.value)}
                        placeholder="e.g. 3298XXXXXXXX" 
                        className="flex-grow bg-black border border-white/20 rounded-lg px-4 py-3 text-white focus:border-[#ff0055] outline-none transition-colors font-mono"
                      />
                      <button 
                        onClick={handleVerify}
                        disabled={isVerifying}
                        className="bg-white text-black font-bold px-8 py-3 rounded-lg hover:bg-[#ff0055] hover:text-white transition-colors disabled:opacity-50"
                      >
                         {isVerifying ? 'Verifying...' : 'Verify'}
                      </button>
                   </div>
                </div>
             </div>
           )}

           {/* --- CARD SECTION --- */}
           {method === 'CARD' && (
             <div className="animate-fade-in-up max-w-md mx-auto">
                {/* Visual Card */}
                <div className="w-full aspect-[1.586/1] bg-gradient-to-br from-[#1a1a1a] to-black rounded-xl border border-white/10 p-6 mb-8 relative overflow-hidden shadow-2xl">
                   <div className="absolute top-0 right-0 w-64 h-64 bg-[#ff0055] opacity-10 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2"></div>
                   <div className="relative z-10 flex flex-col h-full justify-between">
                      <div className="flex justify-between items-start">
                         <div className="w-12 h-8 bg-white/10 rounded-md backdrop-blur-sm border border-white/5"></div>
                         <span className="font-mono text-white/50 text-xs">DEBIT/CREDIT</span>
                      </div>
                      <div>
                         <div className="text-white font-mono text-xl tracking-widest mb-4">0000 0000 0000 0000</div>
                         <div className="flex justify-between text-xs text-white/50 font-mono uppercase">
                            <span>Card Holder</span>
                            <span>Expires</span>
                         </div>
                         <div className="flex justify-between text-white font-mono uppercase text-sm">
                            <span>YOUR NAME</span>
                            <span>MM/YY</span>
                         </div>
                      </div>
                   </div>
                </div>

                <div className="space-y-4">
                   <div>
                      <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">Card Number</label>
                      <div className="relative">
                         <input type="text" placeholder="0000 0000 0000 0000" className="w-full bg-[#111] border border-white/10 rounded-lg p-3 text-white pl-10 focus:border-[#00ccff] outline-none" />
                         <CreditCard className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                      </div>
                   </div>
                   <div className="flex gap-4">
                      <div className="flex-1">
                         <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">Expiry</label>
                         <input type="text" placeholder="MM / YY" className="w-full bg-[#111] border border-white/10 rounded-lg p-3 text-white focus:border-[#00ccff] outline-none" />
                      </div>
                      <div className="flex-1">
                         <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">CVC</label>
                         <input type="text" placeholder="123" className="w-full bg-[#111] border border-white/10 rounded-lg p-3 text-white focus:border-[#00ccff] outline-none" />
                      </div>
                   </div>
                   <button 
                     onClick={handleVerify}
                     disabled={isVerifying}
                     className="w-full py-4 bg-[#00ccff] text-black font-bold uppercase tracking-widest rounded-lg hover:bg-white transition-colors mt-4 shadow-[0_0_20px_rgba(0,204,255,0.3)]"
                   >
                     {isVerifying ? 'Processing...' : `Pay $${resource.price}`}
                   </button>
                   <p className="text-center text-xs text-gray-500">Payments processed securely via Stripe</p>
                </div>
             </div>
           )}

           {/* --- PAYPAL SECTION --- */}
           {method === 'PAYPAL' && (
             <div className="flex flex-col items-center justify-center py-10 animate-fade-in-up">
                <div className="w-20 h-20 bg-[#0070BA]/10 rounded-full flex items-center justify-center mb-6">
                   <Globe className="w-10 h-10 text-[#0070BA]" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Pay via PayPal</h3>
                <p className="text-gray-400 text-sm max-w-xs text-center mb-8">You will be redirected to PayPal's secure checkout page to complete the transaction.</p>
                
                <a href={`https://paypal.me/${PAYPAL_USER}/${resource.price}`} target="_blank" rel="noreferrer" className="w-full max-w-sm">
                   <button className="w-full py-4 bg-[#0070BA] text-white font-bold rounded-full hover:bg-[#005ea6] transition-all shadow-lg hover:scale-105 flex items-center justify-center gap-2">
                      <span className="font-serif italic font-black text-lg">Pay</span> <span className="font-serif italic text-lg">Pal</span>
                   </button>
                </a>
                
                <button 
                  onClick={handleVerify}
                  className="mt-6 text-sm text-gray-400 underline hover:text-white"
                >
                   I have completed the payment
                </button>
             </div>
           )}

           {/* --- CRYPTO SECTION --- */}
           {method === 'CRYPTO' && (
             <div className="animate-fade-in-up">
                <div className="grid grid-cols-3 gap-2 mb-6">
                   {['BTC', 'ETH', 'USDT'].map(coin => (
                      <div key={coin} className="bg-[#111] border border-white/10 p-3 rounded-lg text-center cursor-pointer hover:border-[#ff0055] transition-colors">
                         <span className="font-bold text-white text-sm">{coin}</span>
                      </div>
                   ))}
                </div>
                
                <div className="bg-[#111] border border-white/10 p-6 rounded-xl mb-6 text-center">
                   <p className="text-xs text-gray-500 mb-2">Send exactly <span className="text-white font-bold">${resource.price}</span> worth of BTC to:</p>
                   <div className="bg-black p-3 rounded border border-white/10 flex items-center justify-between gap-4">
                      <code className="text-[#ffaa00] text-xs font-mono break-all">{CRYPTO_WALLETS.BTC}</code>
                      <Copy className="w-4 h-4 text-gray-400 hover:text-white cursor-pointer flex-shrink-0" />
                   </div>
                </div>

                <div className="bg-[#111] border border-white/10 p-6 rounded-xl">
                   <label className="block text-sm font-bold text-white mb-2">Enter Transaction Hash</label>
                   <div className="flex gap-4">
                      <input 
                        type="text" 
                        value={txnId}
                        onChange={(e) => setTxnId(e.target.value)}
                        placeholder="0x..." 
                        className="flex-grow bg-black border border-white/20 rounded-lg px-4 py-3 text-white focus:border-[#ff0055] outline-none transition-colors font-mono text-sm"
                      />
                      <button 
                        onClick={handleVerify}
                        disabled={isVerifying}
                        className="bg-white text-black font-bold px-8 py-3 rounded-lg hover:bg-[#ff0055] hover:text-white transition-colors disabled:opacity-50"
                      >
                         {isVerifying ? 'Checking...' : 'Verify'}
                      </button>
                   </div>
                </div>
             </div>
           )}

           {/* --- DIGITAL WALLETS --- */}
           {method === 'APPLE_GOOGLE' && (
             <div className="flex flex-col items-center justify-center py-10 animate-fade-in-up space-y-4">
                <button onClick={handleVerify} className="w-full max-w-sm py-4 bg-white text-black font-bold rounded-lg hover:scale-105 transition-transform flex items-center justify-center gap-2">
                   <span className="w-5 h-5 bg-black rounded-full"></span> Pay with Apple Pay
                </button>
                <button onClick={handleVerify} className="w-full max-w-sm py-4 bg-black border border-white/20 text-white font-bold rounded-lg hover:scale-105 transition-transform flex items-center justify-center gap-2">
                   <div className="flex gap-0.5">
                      <span className="text-blue-500 font-bold">G</span>
                      <span className="text-red-500 font-bold">o</span>
                      <span className="text-yellow-500 font-bold">o</span>
                      <span className="text-blue-500 font-bold">g</span>
                      <span className="text-green-500 font-bold">l</span>
                      <span className="text-red-500 font-bold">e</span>
                   </div>
                   Pay
                </button>
                <p className="text-xs text-gray-500 mt-4">Simulating native wallet integration.</p>
             </div>
           )}

        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;