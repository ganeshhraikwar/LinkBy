import React, { useRef, useState, useEffect } from 'react';
import { Resource } from '../types';
import { Download, ShoppingBag, Star, HardDrive, Play } from 'lucide-react';

interface ResourceCardProps {
  resource: Resource;
  index: number;
  onOpenProduct: (resource: Resource) => void;
}

const ResourceCard: React.FC<ResourceCardProps> = ({ resource, index, onOpenProduct }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [parallax, setParallax] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    if (!videoRef.current || !resource.videoPreview) return;

    if (isHovered) {
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.catch((error) => {
          console.log("Auto-play prevented:", error);
        });
      }
    } else {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  }, [isHovered, resource.videoPreview]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const rotateX = ((y - centerY) / centerY) * -8; 
    const rotateY = ((x - centerX) / centerX) * 8;
    
    const parallaxX = ((x - centerX) / centerX) * -5; 
    const parallaxY = ((y - centerY) / centerY) * -5;
    
    setRotate({ x: rotateX, y: rotateY });
    setParallax({ x: parallaxX, y: parallaxY });
  };

  const handleMouseEnter = () => setIsHovered(true);
  
  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
    setParallax({ x: 0, y: 0 });
  };

  const isPaid = resource.price && resource.price > 0;
  
  return (
    <div 
      className="perspective-1000 animate-fade-in-up" 
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div 
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onClick={() => onOpenProduct(resource)}
        className="relative group bg-[#0a0a0a] rounded-xl overflow-hidden border border-white/5 hover:border-[#ff0055]/30 transition-all duration-500 ease-out shadow-lg hover:shadow-[0_0_40px_rgba(255,0,85,0.1)] h-full flex flex-col hover:z-20 cursor-pointer"
        style={{
          transform: `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) scale3d(1, 1, 1)`,
          transformStyle: 'preserve-3d',
        }}
      >
        <div className="animate-laser z-30 pointer-events-none opacity-30"></div>

        <div className="relative aspect-[16/9] w-full overflow-hidden bg-black/50 border-b border-white/5">
          {resource.videoPreview && (
            <div className={`absolute inset-0 z-10 transition-opacity duration-500 ease-in-out ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
              <video
                ref={videoRef}
                src={resource.videoPreview}
                muted
                loop
                playsInline
                preload="metadata"
                className="w-full h-full object-cover scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
            </div>
          )}

          <div 
            className="w-full h-full transition-transform duration-100 ease-linear will-change-transform"
            style={{ transform: `translate(${parallax.x}px, ${parallax.y}px)` }}
          >
            <img 
              src={resource.image || `https://picsum.photos/seed/${resource.id}/400/225`} 
              alt={resource.name} 
              className={`w-full h-full object-cover opacity-90 transition-all duration-700 ease-in-out
                ${isHovered && resource.videoPreview ? 'opacity-0' : 'group-hover:scale-105 group-hover:contrast-110'} 
              `}
            />
          </div>
          
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none translate-x-[-100%] group-hover:animate-[shimmer_2s_infinite]" />

          {/* Badges Top Right */}
          <div className="absolute top-3 right-3 flex flex-col gap-2 items-end z-20 pointer-events-none">
            {resource.isNew && (
              <div className="bg-[#ff0055] text-white font-bold text-[10px] px-2 py-0.5 rounded shadow-[0_0_10px_#ff0055] animate-slide-in-left">
                NEW
              </div>
            )}
            {isPaid ? (
               <div className="bg-black/80 backdrop-blur-md border border-[#ff0055]/50 text-white font-bold text-[10px] px-2 py-0.5 rounded flex items-center gap-1 animate-slide-in-left" style={{ animationDelay: '0.1s' }}>
                 PREMIUM
               </div>
            ) : (
               <div className="bg-black/80 backdrop-blur-md border border-[#00ff9d]/50 text-[#00ff9d] font-bold text-[10px] px-2 py-0.5 rounded uppercase tracking-wider animate-slide-in-left" style={{ animationDelay: '0.1s' }}>
                 FREE
               </div>
            )}
          </div>

          {/* Play Preview Indicator (Bottom Right) */}
          {resource.videoPreview && (
             <div className={`absolute bottom-3 right-3 z-20 pointer-events-none transition-all duration-500 ease-in-out ${isHovered ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
                <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-md border border-white/20 px-2.5 py-1 rounded-full shadow-lg">
                   <Play className="w-3 h-3 text-white fill-white" />
                   <span className="text-[10px] font-bold uppercase tracking-wider text-white">Preview</span>
                </div>
             </div>
          )}
          
          <div className="absolute top-3 left-3 z-20 pointer-events-none">
            <div className={`w-8 h-8 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center transition-all duration-500`}>
                {isPaid ? <ShoppingBag className="w-3 h-3 text-white" /> : <Download className="w-3 h-3 text-white" />}
            </div>
          </div>
        </div>

        <div className="p-5 relative z-10 flex flex-col flex-grow bg-[#0a0a0a] translate-z-10 group-hover:bg-[#0e0e0e] transition-colors duration-500">
          <div className="flex items-center justify-between mb-3 overflow-hidden">
            <span className={`text-[10px] uppercase font-bold tracking-[0.2em] transform translate-y-4 opacity-0 animate-fade-in-up ${isPaid ? 'text-[#ff0055]' : 'text-[#00ccff]'}`} style={{ animationDelay: '0.2s', animationFillMode: 'forwards' }}>
              {resource.category}
            </span>
            <span className="text-[10px] text-gray-500 flex items-center gap-1 border border-white/5 px-2 py-0.5 rounded-full transform translate-y-4 opacity-0 animate-fade-in-up" style={{ animationDelay: '0.3s', animationFillMode: 'forwards' }}>
              <HardDrive className="w-3 h-3" /> {resource.size}
            </span>
          </div>

          <div className="relative h-14 mb-2 overflow-hidden group/title">
              <h3 className="font-heading font-bold text-lg leading-tight absolute top-0 left-0 w-full transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)] group-hover:-translate-y-full">
                 <span className="bg-gradient-to-br from-white via-gray-200 to-gray-500 bg-clip-text text-transparent">
                   {resource.name}
                 </span>
              </h3>
              <h3 className="font-heading font-bold text-lg leading-tight absolute top-0 left-0 w-full transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)] translate-y-full group-hover:translate-y-0">
                 <span className="bg-gradient-to-r from-[#ff0055] to-[#00ccff] bg-clip-text text-transparent drop-shadow-[0_0_10px_rgba(255,0,85,0.3)]">
                   {resource.name}
                 </span>
              </h3>
          </div>
          
          <div className="flex items-center gap-2 mb-4 transform translate-y-2 opacity-0 animate-fade-in-up" style={{ animationDelay: '0.4s', animationFillMode: 'forwards' }}>
            {resource.rating && (
                <div className="flex text-yellow-500/80">
                    {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-3 h-3 ${i < Math.floor(resource.rating!) ? 'fill-current' : 'text-gray-800'}`} />
                    ))}
                </div>
            )}
            <span className="text-xs text-gray-600 font-mono">
              {resource.downloadCount.toLocaleString()} dl
            </span>
          </div>
          
          <div className="mt-auto transform translate-y-4 opacity-0 animate-fade-in-up" style={{ animationDelay: '0.5s', animationFillMode: 'forwards' }}>
            <button 
              className={`w-full py-3 rounded font-bold flex items-center justify-center gap-2 transition-all duration-300 relative overflow-hidden group/btn hover:scale-[1.02] active:scale-[0.98] border border-transparent hover:border-white/10
                ${isPaid 
                  ? 'bg-gradient-to-r from-[#ff0055] to-[#aa0033] text-white shadow-[0_4px_20px_rgba(255,0,85,0.2)]' 
                  : 'bg-[#1a1a1a] text-white hover:bg-[#252525]'
                }`}
            >
              <div className="absolute top-0 -left-[100%] w-1/2 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[-20deg] group-hover/btn:animate-[shimmer_0.6s_ease-in-out_infinite]" />
              
              <span className="relative z-10 flex items-center gap-2">
                {isPaid ? (
                  <>
                    <ShoppingBag className="w-4 h-4 group-hover/btn:animate-wiggle" />
                    Buy <span className="text-white/40 mx-1">|</span> ${resource.price?.toFixed(2)}
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 group-hover/btn:animate-bounce" />
                    Download
                  </>
                )}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceCard;