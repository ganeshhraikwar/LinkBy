import React, { useEffect, useRef } from 'react';

const CustomCursor: React.FC = () => {
  const dotRef = useRef<HTMLDivElement>(null);
  const outlineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      
      if (dotRef.current) {
        dotRef.current.style.left = `${clientX}px`;
        dotRef.current.style.top = `${clientY}px`;
      }
      
      // Add slight delay/lag to outline for fluid feel
      if (outlineRef.current) {
        outlineRef.current.animate({
          left: `${clientX}px`,
          top: `${clientY}px`
        }, { duration: 500, fill: "forwards" });
      }
    };

    const handleHoverStart = () => {
      if (outlineRef.current) {
        outlineRef.current.style.transform = 'translate(-50%, -50%) scale(1.5)';
        outlineRef.current.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
        outlineRef.current.style.borderColor = 'transparent';
      }
    };

    const handleHoverEnd = () => {
      if (outlineRef.current) {
        outlineRef.current.style.transform = 'translate(-50%, -50%) scale(1)';
        outlineRef.current.style.backgroundColor = 'transparent';
        outlineRef.current.style.borderColor = 'rgba(255, 255, 255, 0.5)';
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    
    // Add hover listeners to all clickable elements dynamically
    const clickables = document.querySelectorAll('a, button, input, .cursor-pointer');
    clickables.forEach(el => {
      el.addEventListener('mouseenter', handleHoverStart);
      el.addEventListener('mouseleave', handleHoverEnd);
    });

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      clickables.forEach(el => {
        el.removeEventListener('mouseenter', handleHoverStart);
        el.removeEventListener('mouseleave', handleHoverEnd);
      });
    };
  }, []);

  return (
    <>
      <div ref={dotRef} className="cursor-dot hidden md:block mix-blend-difference"></div>
      <div ref={outlineRef} className="cursor-outline hidden md:block mix-blend-difference"></div>
    </>
  );
};

export default CustomCursor;