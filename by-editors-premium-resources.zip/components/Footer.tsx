import React from 'react';
import { Youtube, Instagram, Twitter, ArrowRight, Zap, Globe, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="mt-20 border-t border-white/10 bg-[#050505] text-gray-400 relative overflow-hidden z-10">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#ff0055] opacity-[0.03] blur-[150px] pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#00ccff] opacity-[0.03] blur-[150px] pointer-events-none"></div>

      <div className="max-w-[1600px] mx-auto px-6 md:px-12 py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 relative z-10">
        
        {/* Column 1: Brand & Vision */}
        <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center gap-2 group cursor-default">
             <div className="w-8 h-8 rounded bg-gradient-to-br from-[#ff0055] to-[#990033] flex items-center justify-center shadow-[0_0_15px_rgba(255,0,85,0.4)] group-hover:rotate-12 transition-transform duration-500">
                <Zap className="text-white w-5 h-5 fill-current" />
             </div>
             <h2 className="font-heading text-2xl font-bold text-white tracking-tight">BY EDITORS</h2>
          </div>
          <p className="text-sm leading-relaxed text-gray-500">
            The ultimate resource library for next-gen video editors. We provide the ammunition; you create the masterpiece. Edit like a god.
          </p>
          <div className="flex gap-4">
             <a href="#" className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#ff0055] hover:border-[#ff0055] hover:text-white transition-all duration-300 hover:scale-110 group">
                <Youtube className="w-5 h-5 group-hover:animate-wiggle" />
             </a>
             <a href="#" className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#E1306C] hover:border-[#E1306C] hover:text-white transition-all duration-300 hover:scale-110 group">
                <Instagram className="w-5 h-5 group-hover:animate-wiggle" />
             </a>
             <a href="#" className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#1DA1F2] hover:border-[#1DA1F2] hover:text-white transition-all duration-300 hover:scale-110 group">
                <Twitter className="w-5 h-5 group-hover:animate-wiggle" />
             </a>
          </div>
        </div>

        {/* Column 2: Meet the Creator */}
        <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
           <h3 className="text-white font-bold uppercase tracking-widest text-sm border-l-2 border-[#ff0055] pl-3">Meet The Creator</h3>
           <div className="flex items-start gap-4 p-4 rounded-xl bg-white/5 border border-white/5 hover:border-white/20 transition-colors group">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-gray-700 to-gray-900 border-2 border-[#ff0055] overflow-hidden flex-shrink-0 shadow-[0_0_10px_#ff0055]">
                 {/* Generic avatar since we don't have the user's real image, using a stylized abstract or generic person */}
                 <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop" alt="Creator" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity grayscale group-hover:grayscale-0" />
              </div>
              <div>
                 <h4 className="text-white font-bold text-sm group-hover:text-[#ff0055] transition-colors">Ganesh</h4>
                 <p className="text-[10px] text-[#00ccff] font-mono mb-2 uppercase tracking-wide">Head of Design</p>
                 <p className="text-xs text-gray-400 leading-snug">
                    "I built this platform to give editors the tools I wished I had when I started. Quality over quantity, always."
                 </p>
              </div>
           </div>
           <a href="#" className="inline-flex items-center gap-2 text-xs font-bold text-gray-400 hover:text-white transition-colors group">
              <Globe className="w-3 h-3 group-hover:rotate-12 transition-transform" /> Visit Portfolio <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
           </a>
        </div>

        {/* Column 3: Quick Links */}
        <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
           <h3 className="text-white font-bold uppercase tracking-widest text-sm border-l-2 border-[#00ccff] pl-3">System Navigation</h3>
           <ul className="space-y-3 text-sm">
              {['New Arrivals', 'Premium Bundles', 'Free Assets', 'Tutorials', 'License Agreement'].map((item) => (
                 <li key={item}>
                    <a href="#" className="hover:text-[#00ccff] transition-colors flex items-center gap-2 group">
                       <span className="w-1 h-1 bg-gray-600 rounded-full group-hover:bg-[#00ccff] group-hover:scale-150 transition-all"></span>
                       {item}
                    </a>
                 </li>
              ))}
           </ul>
        </div>

        {/* Column 4: Newsletter */}
        <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
           <h3 className="text-white font-bold uppercase tracking-widest text-sm border-l-2 border-[#00ff9d] pl-3">Join The Elite</h3>
           <p className="text-xs text-gray-500">Get exclusive freebies and early access to new drops.</p>
           <div className="relative group">
              <input 
                type="email" 
                placeholder="ENTER EMAIL ID" 
                className="w-full bg-black border border-white/10 text-white px-4 py-3 text-xs font-mono focus:outline-none focus:border-[#00ff9d] transition-colors pr-10 rounded-sm"
              />
              <button className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-[#00ff9d] transition-colors">
                 <ArrowRight className="w-4 h-4" />
              </button>
           </div>
           <div className="flex items-center gap-2 text-[10px] text-gray-600">
              <Zap className="w-3 h-3 text-[#ff0055]" />
              <span>No spam. Only fire assets.</span>
           </div>
        </div>

      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5 bg-black/50 backdrop-blur-md relative z-10">
         <div className="max-w-[1600px] mx-auto px-6 md:px-12 py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono">
            <p className="text-gray-600">&copy; {new Date().getFullYear()} BY EDITORS. All Rights Reserved.</p>
            <div className="flex items-center gap-1 text-gray-500">
               <span>Made with</span>
               <Heart className="w-3 h-3 text-[#ff0055] fill-current animate-pulse" />
               <span>by Ganesh</span>
            </div>
            <div className="flex gap-6 text-gray-600">
               <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
               <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
         </div>
      </div>
    </footer>
  );
};

export default Footer;