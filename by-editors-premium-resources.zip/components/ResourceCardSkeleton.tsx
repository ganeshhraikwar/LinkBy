import React from 'react';

const ResourceCardSkeleton: React.FC = () => {
  return (
    <div className="bg-[#0a0a0a] rounded-xl overflow-hidden border border-white/5 h-full flex flex-col relative animate-pulse">
      {/* Image Placeholder */}
      <div className="relative aspect-[16/9] w-full bg-white/5 overflow-hidden">
        <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/10 to-transparent z-10"></div>
        {/* Badge Placeholder */}
        <div className="absolute top-3 right-3 w-16 h-6 bg-white/10 rounded"></div>
      </div>
      
      {/* Content Placeholder */}
      <div className="p-5 flex flex-col flex-grow relative overflow-hidden gap-4">
         {/* Shimmer Overlay for content */}
         <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/5 to-transparent z-10" style={{ animationDelay: '0.1s' }}></div>
         
         {/* Meta Row */}
         <div className="flex justify-between items-center">
            <div className="h-3 w-20 bg-white/10 rounded"></div>
            <div className="h-3 w-16 bg-white/10 rounded"></div>
         </div>
         
         {/* Title */}
         <div className="space-y-2">
            <div className="h-6 w-3/4 bg-white/10 rounded"></div>
            <div className="h-6 w-1/2 bg-white/10 rounded"></div>
         </div>
         
         {/* Rating/Downloads */}
         <div className="flex gap-2">
             <div className="h-3 w-24 bg-white/10 rounded"></div>
         </div>
         
         {/* Button */}
         <div className="mt-auto pt-2">
            <div className="h-10 w-full bg-white/10 rounded"></div>
         </div>
      </div>
    </div>
  );
};

export default ResourceCardSkeleton;