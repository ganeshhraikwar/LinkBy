import React, { useState, useMemo, useEffect } from 'react';
import Navbar from './components/Navbar';
import ResourceCard from './components/ResourceCard';
import ResourceCardSkeleton from './components/ResourceCardSkeleton';
import CategoryFilter from './components/CategoryFilter';
import Footer from './components/Footer';
import CustomCursor from './components/CustomCursor';
import BackgroundEffects from './components/BackgroundEffects';
import PromoBanner from './components/PromoBanner';
import CheckoutModal from './components/CheckoutModal';
import ProductModal from './components/ProductModal';
import AdminPanel from './components/AdminPanel';
import { resources } from './data/resources';
import { Category, Resource } from './types';
import { Search, Sparkles, Zap, Box, Layers, Star, Flame, Lock } from 'lucide-react';

const App: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category>('All');
  const [mounted, setMounted] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // Modal States
  const [activeProduct, setActiveProduct] = useState<Resource | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Initial load simulation
  useEffect(() => {
    setMounted(true);
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  // Filter load simulation
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, [selectedCategory, searchTerm]);

  // Filter Logic
  const filteredResources = useMemo(() => {
    return resources.filter((resource: Resource) => {
      const matchesSearch = resource.name.toLowerCase().includes(searchTerm.toLowerCase());
      
      let matchesCategory = false;
      if (selectedCategory === 'All') {
        matchesCategory = true;
      } else if (selectedCategory === 'New Arrivals') {
        matchesCategory = resource.isNew === true;
      } else {
        matchesCategory = resource.category === selectedCategory;
      }

      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, selectedCategory]);

  const handleProductBuy = () => {
    if (activeProduct) {
       // Close detail modal, open checkout
       setIsCheckoutOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#030303] text-white selection:bg-[#ff0055] selection:text-white font-sans relative overflow-hidden animate-fade-in-up">
      <CustomCursor />
      <BackgroundEffects />
      <Navbar />

      {/* Hero Section - Optimized Spacing */}
      <div className="relative pt-28 pb-10 px-4 md:px-12">
        <div className="relative z-10 flex flex-col items-center text-center max-w-5xl mx-auto">
          
          <div className="animate-pop-in" style={{ animationDelay: '0.2s' }}>
            <div className="inline-flex items-center gap-2 px-6 py-2 rounded border border-[#ff0055]/30 bg-[#ff0055]/5 text-white text-xs font-bold uppercase tracking-[0.2em] mb-6 hover:bg-[#ff0055]/10 transition-colors cursor-default backdrop-blur-md relative overflow-hidden group hover:scale-105 duration-300">
                <span className="absolute inset-0 bg-[#ff0055]/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></span>
                <Zap className="w-4 h-4 text-[#ff0055] animate-pulse" />
                <span>BY EDITORS • V2.0</span>
            </div>
          </div>

          <h1 className="font-heading text-5xl md:text-8xl font-extrabold tracking-tighter mb-6 leading-[0.9] text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.1)] glitch-text animate-slide-down" style={{ animationDelay: '0.3s' }} data-text="EDIT LIKE A GOD">
            EDIT LIKE <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-b from-[#ff0055] to-[#aa0033] inline-block hover:scale-105 transition-transform duration-500 cursor-default hover:animate-pulse-slow">
              A GOD.
            </span>
          </h1>
          
          <div className="animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
            <p className="text-gray-400 text-lg md:text-xl max-w-3xl mb-8 leading-relaxed font-light">
                Access the <span className="text-white font-bold underline decoration-[#00ccff] decoration-2 underline-offset-4 hover:text-[#00ccff] transition-colors">forbidden library</span> of high-end assets.
                <br className="hidden md:block"/> 
                Used by top creators. Now available for you.
            </p>
          </div>

          <div className="relative w-full max-w-2xl group mx-auto perspective-1000 animate-pop-in" style={{ animationDelay: '0.7s' }}>
            <div className="absolute -inset-1 bg-gradient-to-r from-[#ff0055] to-[#00ccff] rounded-lg blur opacity-20 group-hover:opacity-60 transition duration-500 group-focus-within:opacity-100 group-focus-within:blur-md animate-pulse-slow"></div>
            <div className="relative bg-black rounded-lg border border-white/10 flex items-center p-2 transform transition-transform group-hover:scale-[1.01] group-focus-within:scale-105 duration-300 shadow-2xl">
                <div className="pl-4">
                  <Search className="w-6 h-6 text-gray-500 group-focus-within:text-[#ff0055] transition-colors group-focus-within:animate-wiggle" />
                </div>
                <input
                  type="text"
                  placeholder="SEARCH DATABASE..."
                  className="w-full bg-transparent border-none text-white px-4 py-4 focus:outline-none placeholder-gray-700 font-bold uppercase tracking-widest text-lg"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <button className="bg-white text-black font-bold uppercase text-xs px-6 py-3 rounded hover:bg-[#ff0055] hover:text-white transition-all hover:scale-110 active:scale-90 hover:shadow-[0_0_15px_#ff0055]">
                    Search
                </button>
            </div>
          </div>
        </div>
      </div>

      <div className="mb-12 animate-fade-in-up" style={{ animationDelay: '0.9s' }}>
         <PromoBanner />
      </div>

      <div className="border-y border-white/5 bg-black/50 backdrop-blur-sm mb-12 relative z-20 overflow-hidden">
         <div className="absolute inset-0 bg-white/5 skew-x-12 translate-x-[-100%] animate-[shimmer_5s_infinite]"></div>
         <div className="max-w-[1600px] mx-auto px-4 py-8 grid grid-cols-2 md:grid-cols-4 gap-12">
            {[
              { icon: Box, val: '500+', label: 'ASSETS', color: '#ff0055' },
              { icon: Layers, val: '4K', label: 'QUALITY', color: '#00ccff' },
              { icon: Zap, val: '0.1s', label: 'INSTANT DL', color: '#00ff9d' },
              { icon: Flame, val: 'PRO', label: 'VFX', color: '#ffaa00' },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center text-center group cursor-default animate-pop-in" style={{ animationDelay: `${1 + (i * 0.1)}s` }}>
                 <stat.icon className="w-8 h-8 mb-4 transition-transform group-hover:scale-125 group-hover:rotate-12 duration-300 animate-float" style={{ animationDelay: `${i * 0.5}s`, color: stat.color }} />
                 <span className="text-4xl font-black font-heading tracking-tighter mb-1 group-hover:text-white transition-colors text-gray-300 group-hover:scale-110 duration-200 block">{stat.val}</span>
                 <span className="text-[10px] text-gray-600 font-bold uppercase tracking-[0.3em]" style={{ color: stat.color }}>{stat.label}</span>
              </div>
            ))}
         </div>
      </div>

      <main className="px-4 md:px-12 pb-32 max-w-[1800px] mx-auto relative z-10">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-8 animate-fade-in-up" style={{ animationDelay: '1.2s' }}>
          <div className="group">
             <h2 className="font-heading text-4xl md:text-5xl font-bold mb-2 flex items-center gap-3 group-hover:translate-x-2 transition-transform duration-300">
               <span className="text-[#ff0055] animate-pulse">●</span> 
               SYSTEM ASSETS
             </h2>
             <p className="text-gray-500 uppercase tracking-widest text-xs font-bold group-hover:text-white transition-colors">Browse the complete collection</p>
          </div>
          <CategoryFilter selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />
        </div>

        {isLoading ? (
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
             {[...Array(8)].map((_, i) => (
               <ResourceCardSkeleton key={i} />
             ))}
           </div>
        ) : filteredResources.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredResources.map((item, index) => (
              <ResourceCard 
                key={item.id} 
                resource={item} 
                index={index} 
                onOpenProduct={(res) => {
                   setActiveProduct(res);
                   // If it's free, we might want to let them download directly, or show modal
                   // Currently logic is: Always show details modal first
                }}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-40 bg-[#0a0a0a] border border-white/5 rounded-2xl relative overflow-hidden group animate-pop-in">
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
            <div className="relative z-10 flex flex-col items-center">
                <Search className="w-16 h-16 text-gray-800 mb-6 group-hover:text-[#ff0055] transition-colors duration-500 animate-wiggle" />
                <h3 className="font-heading text-3xl text-white font-bold mb-2 uppercase tracking-tight">Data Not Found</h3>
                <p className="text-gray-600 font-mono text-sm mb-8">System could not locate requested assets.</p>
                <button 
                  onClick={() => {setSearchTerm(''); setSelectedCategory('All');}}
                  className="px-8 py-3 bg-[#ff0055] text-white font-bold uppercase tracking-widest text-xs hover:bg-white hover:text-black transition-all shadow-[0_0_20px_#ff0055] hover:scale-110 active:scale-95"
                >
                  Reset System
                </button>
            </div>
          </div>
        )}
      </main>
      
      <Footer />

      {/* Secret Admin Button */}
      <div className="fixed bottom-4 left-4 z-50">
         <button onClick={() => setIsAdminOpen(true)} className="opacity-0 hover:opacity-100 transition-opacity text-xs font-mono text-gray-800 flex items-center gap-1">
            <Lock className="w-3 h-3" /> Admin Access
         </button>
      </div>

      {/* Modals */}
      {isAdminOpen && <AdminPanel onClose={() => setIsAdminOpen(false)} />}
      
      {activeProduct && !isCheckoutOpen && (
        <ProductModal 
          resource={activeProduct} 
          onClose={() => setActiveProduct(null)} 
          onBuy={handleProductBuy} 
        />
      )}

      {isCheckoutOpen && activeProduct && (
        <CheckoutModal 
          resource={activeProduct} 
          onClose={() => setIsCheckoutOpen(false)} 
        />
      )}

    </div>
  );
};

export default App;