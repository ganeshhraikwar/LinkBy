export type Category = 
  | 'All' 
  | 'New Arrivals' 
  | 'Mobile Editing' 
  | 'PC Software' 
  | 'Plugins' 
  | 'GFX' 
  | 'Overlays' 
  | 'Motion' 
  | 'Presets' 
  | 'Sound' 
  | '3D Assets'
  | 'PNGs'
  | 'Icons'
  | 'GIFs'
  | 'Backgrounds';

export interface Resource {
  id: string;
  name: string;
  size: string;
  link: string; // URL for download (Google Drive/Mediafire)
  category: Category;
  downloadCount: number;
  isPremium?: boolean; // If true, it triggers the payment modal
  price?: number; // 0 = Free
  image?: string; // Optional custom thumbnail URL
  videoPreview?: string; // Optional video preview URL
  rating?: number;
  isNew?: boolean; 
  longDescription?: string; // HTML allowed description
}